import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Landing from "./pages/Landing";
import Verify from "./pages/Verify";
import Scanner from "./pages/Scanner";
import Results from "./pages/Results";
import History from "./pages/History";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Landing} />
      <Route path="/verify" component={Verify} />
      <Route path="/scan" component={Scanner} />
      <Route path="/results/:scanId" component={Results} />
      <Route path="/history" component={History} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster
            theme="dark"
            toastOptions={{
              style: {
                background: "oklch(0.14 0.015 264)",
                border: "1px solid oklch(0.22 0.015 264)",
                color: "oklch(0.96 0.005 264)",
              },
            }}
          />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
