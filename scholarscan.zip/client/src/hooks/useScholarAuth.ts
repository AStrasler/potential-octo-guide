import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";

export function useScholarAuth() {
  const { data, isLoading, refetch } = trpc.emailAuth.getSession.useQuery(undefined, {
    retry: false,
    staleTime: 30_000,
  });

  return {
    email: data?.email ?? null,
    authenticated: data?.authenticated ?? false,
    loading: isLoading,
    refetch,
  };
}

export function useRequireAuth() {
  const [, navigate] = useLocation();
  const auth = useScholarAuth();

  if (!auth.loading && !auth.authenticated) {
    navigate("/verify");
  }

  return auth;
}
