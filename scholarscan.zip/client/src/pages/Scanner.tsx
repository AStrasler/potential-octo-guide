import { useState, useRef, useCallback, useEffect } from "react";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { useRequireAuth } from "@/hooks/useScholarAuth";
import {
  GraduationCap,
  Upload,
  FileText,
  Plus,
  X,
  Zap,
  History,
  LogOut,
  Sparkles,
  Search,
  BookOpen,
  Loader2,
  ChevronRight,
} from "lucide-react";

const MAX_CHARS = 50000;

export default function Scanner() {
  const [, navigate] = useLocation();
  const { email, loading } = useRequireAuth();
  const [text, setText] = useState("");
  const [fileName, setFileName] = useState<string | undefined>();
  const [citations, setCitations] = useState<string[]>([""]);
  const [isDragging, setIsDragging] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const signOut = trpc.emailAuth.signOut.useMutation({
    onSuccess: () => navigate("/"),
  });

  const submitScan = trpc.scan.submit.useMutation({
    onSuccess: (data) => {
      navigate(`/results/${data.scanId}`);
    },
    onError: (err) => {
      toast.error("Scan failed: " + err.message);
    },
  });

  const handleFile = useCallback(async (file: File) => {
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast.error("File too large. Maximum 5MB.");
      return;
    }
    setFileName(file.name);
    if (file.name.endsWith(".txt")) {
      const content = await file.text();
      setText(content.slice(0, MAX_CHARS));
    } else if (file.name.endsWith(".docx")) {
      // Send the .docx file to the server for proper text extraction
      try {
        const formData = new FormData();
        formData.append("file", file);
        const response = await fetch("/api/extract-docx", { method: "POST", body: formData });
        if (!response.ok) throw new Error("Server extraction failed");
        const { text: extracted } = await response.json();
        setText(extracted.slice(0, MAX_CHARS));
        toast.success("Document text extracted successfully.");
      } catch {
        toast.error("Could not extract .docx text. Please paste your text directly.");
        setFileName(undefined);
      }
    } else {
      toast.error("Only .txt and .docx files are supported.");
    }
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      const file = e.dataTransfer.files[0];
      if (file) handleFile(file);
    },
    [handleFile]
  );

  const handleSubmit = () => {
    if (text.trim().length < 10) {
      toast.error("Please enter at least 10 characters of text.");
      return;
    }
    const validCitations = citations.filter((c) => c.trim().length > 0);
    submitScan.mutate({ text: text.trim(), fileName, citations: validCitations });
  };

  const wordCount = text.trim() ? text.trim().split(/\s+/).length : 0;
  const charCount = text.length;

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-6 h-6 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Background */}
      <div
        className="fixed inset-0 opacity-[0.02] pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(oklch(0.72 0.18 264) 1px, transparent 1px), linear-gradient(90deg, oklch(0.72 0.18 264) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />

      {/* Nav */}
      <nav className="sticky top-0 z-50 scholar-glass border-b border-border/50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/20 border border-primary/30 flex items-center justify-center">
              <GraduationCap className="w-4 h-4 text-primary" />
            </div>
            <span className="font-semibold tracking-tight">ScholarScan</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="hidden sm:block text-xs text-muted-foreground">{email}</span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/history")}
              className="text-muted-foreground hover:text-foreground"
            >
              <History className="w-4 h-4 mr-1.5" />
              History
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => signOut.mutate()}
              className="text-muted-foreground hover:text-foreground"
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </nav>

      <main className="container py-10 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: [0.23, 1, 0.32, 1] }}
          className="max-w-4xl mx-auto"
        >
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold tracking-tight mb-2">New Scan</h1>
            <p className="text-muted-foreground">
              Submit your text for AI detection, plagiarism analysis, and citation validation.
            </p>
          </div>

          {/* What gets checked */}
          <div className="grid grid-cols-3 gap-3 mb-8">
            {[
              { icon: Sparkles, label: "AI Detection", color: "oklch(0.72 0.18 264)" },
              { icon: Search, label: "Plagiarism", color: "oklch(0.72 0.18 145)" },
              { icon: BookOpen, label: "Citations", color: "oklch(0.72 0.18 55)" },
            ].map((item) => (
              <div
                key={item.label}
                className="flex items-center gap-2 scholar-card rounded-lg px-3 py-2.5"
              >
                <item.icon className="w-4 h-4 flex-shrink-0" style={{ color: item.color }} />
                <span className="text-sm font-medium">{item.label}</span>
              </div>
            ))}
          </div>

          <Tabs defaultValue="text" className="space-y-6">
            <TabsList className="bg-muted/50 border border-border">
              <TabsTrigger value="text" className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary">
                <FileText className="w-3.5 h-3.5 mr-1.5" />
                Paste Text
              </TabsTrigger>
              <TabsTrigger value="file" className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary">
                <Upload className="w-3.5 h-3.5 mr-1.5" />
                Upload File
              </TabsTrigger>
            </TabsList>

            <TabsContent value="text" className="space-y-0">
              <div className="scholar-card rounded-xl overflow-hidden">
                <div className="p-1">
                  <Textarea
                    placeholder="Paste or type your text here... (minimum 10 characters)"
                    value={text}
                    onChange={(e) => setText(e.target.value.slice(0, MAX_CHARS))}
                    className="min-h-[280px] bg-transparent border-0 focus-visible:ring-0 text-base leading-relaxed resize-none p-4"
                  />
                </div>
                <div className="flex items-center justify-between px-4 py-2.5 border-t border-border/50">
                  <span className="text-xs text-muted-foreground">
                    {wordCount.toLocaleString()} words · {charCount.toLocaleString()} / {MAX_CHARS.toLocaleString()} chars
                  </span>
                  {text && (
                    <button
                      onClick={() => { setText(""); setFileName(undefined); }}
                      className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 transition-colors"
                    >
                      <X className="w-3 h-3" /> Clear
                    </button>
                  )}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="file">
              <div
                className={`scholar-card rounded-xl border-2 border-dashed transition-colors duration-200 ${
                  isDragging ? "border-primary bg-primary/5" : "border-border/60"
                }`}
                onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
              >
                <div className="flex flex-col items-center justify-center py-16 px-8 text-center">
                  <div className="w-12 h-12 rounded-xl bg-primary/15 border border-primary/25 flex items-center justify-center mb-4">
                    <Upload className="w-6 h-6 text-primary" />
                  </div>
                  {fileName ? (
                    <>
                      <p className="font-medium mb-1">{fileName}</p>
                      <p className="text-sm text-muted-foreground mb-4">
                        {wordCount.toLocaleString()} words loaded
                      </p>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => { setFileName(undefined); setText(""); }}
                      >
                        Remove file
                      </Button>
                    </>
                  ) : (
                    <>
                      <p className="font-medium mb-1">Drop your file here</p>
                      <p className="text-sm text-muted-foreground mb-4">
                        Supports .txt and .docx files up to 5MB
                      </p>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => fileRef.current?.click()}
                      >
                        Browse files
                      </Button>
                    </>
                  )}
                  <input
                    ref={fileRef}
                    type="file"
                    accept=".txt,.docx"
                    className="hidden"
                    onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
                  />
                </div>
              </div>
            </TabsContent>
          </Tabs>

          {/* Citations section */}
          <div className="mt-6">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="font-medium flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-muted-foreground" />
                  Citations to validate
                  <Badge variant="outline" className="text-xs font-normal">Optional</Badge>
                </h3>
                <p className="text-xs text-muted-foreground mt-0.5">
                  APA, MLA, Chicago, or Harvard format
                </p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setCitations([...citations, ""])}
                className="text-primary hover:text-primary/80 hover:bg-primary/10"
              >
                <Plus className="w-3.5 h-3.5 mr-1" />
                Add citation
              </Button>
            </div>

            <div className="space-y-2">
              {citations.map((citation, i) => (
                <div key={i} className="flex gap-2">
                  <input
                    type="text"
                    placeholder={`Citation ${i + 1} — e.g., Smith, J. (2023). Title. Journal, 1(1), 1-10.`}
                    value={citation}
                    onChange={(e) => {
                      const updated = [...citations];
                      updated[i] = e.target.value;
                      setCitations(updated);
                    }}
                    className="flex-1 h-10 px-3 text-sm rounded-lg bg-muted/50 border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors"
                  />
                  {citations.length > 1 && (
                    <button
                      onClick={() => setCitations(citations.filter((_, j) => j !== i))}
                      className="w-10 h-10 flex items-center justify-center rounded-lg border border-border text-muted-foreground hover:text-destructive hover:border-destructive/50 transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Submit */}
          <div className="mt-8 flex items-center justify-between">
            <p className="text-xs text-muted-foreground">
              All three checks run simultaneously — results in ~30 seconds.
            </p>
            <Button
              size="lg"
              onClick={handleSubmit}
              disabled={submitScan.isPending || text.trim().length < 10}
              className="bg-primary text-primary-foreground hover:bg-primary/90 px-8 h-12 font-medium shadow-lg shadow-primary/20 transition-all duration-150 active:scale-[0.97] disabled:opacity-50"
            >
              {submitScan.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 mr-2" />
                  Run Full Analysis
                  <ChevronRight className="w-4 h-4 ml-1" />
                </>
              )}
            </Button>
          </div>
        </motion.div>
      </main>
    </div>
  );
}
