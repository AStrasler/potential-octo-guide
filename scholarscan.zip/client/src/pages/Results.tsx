import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation, useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useRequireAuth } from "@/hooks/useScholarAuth";
import {
  GraduationCap,
  ArrowLeft,
  History,
  LogOut,
  Sparkles,
  Search,
  BookOpen,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Info,
  Download,
  Loader2,
  RefreshCw,
  FileText,
} from "lucide-react";

// ─── Score helpers ─────────────────────────────────────────────────────────────

function getAIScoreColor(score: number) {
  if (score >= 70) return "oklch(0.65 0.22 25)";
  if (score >= 40) return "oklch(0.72 0.18 55)";
  return "oklch(0.72 0.18 145)";
}

function getAIVerdict(score: number) {
  if (score >= 70) return { label: "Likely AI-Written", variant: "destructive" as const };
  if (score >= 40) return { label: "Possibly AI-Written", variant: "secondary" as const };
  return { label: "Likely Human-Written", variant: "outline" as const };
}

function getPlagiarismColor(score: number) {
  if (score >= 80) return "oklch(0.72 0.18 145)";
  if (score >= 50) return "oklch(0.72 0.18 55)";
  return "oklch(0.65 0.22 25)";
}

function getPlagiarismVerdict(score: number) {
  if (score >= 80) return { label: "Highly Original", variant: "outline" as const };
  if (score >= 50) return { label: "Some Similarities", variant: "secondary" as const };
  return { label: "High Plagiarism Risk", variant: "destructive" as const };
}

// ─── Animated score gauge ─────────────────────────────────────────────────────

function ScoreGauge({ score, color, label, sublabel }: { score: number; color: string; label: string; sublabel: string }) {
  const [displayed, setDisplayed] = useState(0);
  useEffect(() => {
    const duration = 1200;
    const start = Date.now();
    const tick = () => {
      const elapsed = Date.now() - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplayed(Math.round(eased * score));
      if (progress < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [score]);

  const radius = 52;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (displayed / 100) * circumference;

  return (
    <div className="flex flex-col items-center">
      <div className="relative w-36 h-36">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120">
          <circle cx="60" cy="60" r={radius} fill="none" stroke="oklch(0.20 0.015 264)" strokeWidth="8" />
          <circle
            cx="60"
            cy="60"
            r={radius}
            fill="none"
            stroke={color}
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            style={{ transition: "stroke-dashoffset 0.05s linear", filter: `drop-shadow(0 0 6px ${color}60)` }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-3xl font-bold" style={{ color }}>{displayed}%</span>
        </div>
      </div>
      <div className="text-center mt-2">
        <p className="font-semibold text-sm">{label}</p>
        <p className="text-xs text-muted-foreground">{sublabel}</p>
      </div>
    </div>
  );
}

// ─── Highlighted text ─────────────────────────────────────────────────────────

function HighlightedText({ text, sentences }: { text: string; sentences: any[] }) {
  if (!sentences?.length) return <p className="text-sm leading-relaxed text-foreground/90">{text}</p>;

  const parts: Array<{ text: string; score?: number; reasoning?: string }> = [];
  let lastIdx = 0;

  const sorted = [...sentences].sort((a, b) => a.startIdx - b.startIdx);
  for (const s of sorted) {
    if (s.startIdx > lastIdx) {
      parts.push({ text: text.slice(lastIdx, s.startIdx) });
    }
    parts.push({ text: s.text, score: s.aiProbability, reasoning: s.reasoning });
    lastIdx = s.endIdx;
  }
  if (lastIdx < text.length) parts.push({ text: text.slice(lastIdx) });

  return (
    <p className="text-sm leading-relaxed text-foreground/90">
      {parts.map((part, i) => {
        if (part.score === undefined) return <span key={i}>{part.text}</span>;
        const cls =
          part.score >= 70 ? "highlight-ai-high" : part.score >= 40 ? "highlight-ai-medium" : "highlight-ai-low";
        return (
          <span key={i} className={`${cls} cursor-help`} title={`AI probability: ${part.score}% — ${part.reasoning}`}>
            {part.text}
          </span>
        );
      })}
    </p>
  );
}

// ─── Main Results page ────────────────────────────────────────────────────────

export default function Results() {
  const params = useParams<{ scanId: string }>();
  const scanId = parseInt(params.scanId ?? "0");
  const [, navigate] = useLocation();
  const { email } = useRequireAuth();
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(["ai", "plagiarism", "citations"]));
  const [isExporting, setIsExporting] = useState(false);

  const signOut = trpc.emailAuth.signOut.useMutation({ onSuccess: () => navigate("/") });

  const { data, isLoading, refetch } = trpc.scan.getResult.useQuery(
    { scanId },
    { enabled: !!scanId, refetchInterval: (query) => {
      const scan = query.state.data?.scan;
      if (!scan || scan.status === "processing" || scan.status === "pending") return 2000;
      return false;
    }}
  );

  const scan = data?.scan;
  const result = data?.result;
  const isProcessing = scan?.status === "processing" || scan?.status === "pending";
  const isFailed = scan?.status === "failed";

  const aiDetails = result?.aiDetailsJson as any;
  const plagiarismDetails = result?.plagiarismDetailsJson as any;
  const citationDetails = result?.citationsJson as any;

  const toggleSection = (key: string) => {
    setExpandedSections((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const handleExportPDF = async () => {
    setIsExporting(true);
    try {
      const { jsPDF } = await import("jspdf");
      const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
      const pageWidth = doc.internal.pageSize.getWidth();
      const margin = 20;
      let y = 20;

      const addText = (text: string, size: number, bold = false, color = [30, 30, 30] as [number, number, number]) => {
        doc.setFontSize(size);
        doc.setFont("helvetica", bold ? "bold" : "normal");
        doc.setTextColor(...color);
        const lines = doc.splitTextToSize(text, pageWidth - margin * 2);
        doc.text(lines, margin, y);
        y += lines.length * (size * 0.4) + 4;
        if (y > 270) { doc.addPage(); y = 20; }
      };

      addText("ScholarScan — Academic Integrity Report", 18, true, [30, 30, 100]);
      addText(`Generated: ${new Date().toLocaleString()}`, 9, false, [100, 100, 100]);
      addText(`Email: ${email ?? ""}`, 9, false, [100, 100, 100]);
      y += 4;

      if (result?.aiScore !== null && result?.aiScore !== undefined) {
        addText("AI Content Detection", 13, true);
        addText(`Overall AI Score: ${result.aiScore}%`, 11);
        addText(`Verdict: ${getAIVerdict(result.aiScore).label}`, 10);
        if (aiDetails?.summary) addText(aiDetails.summary, 9, false, [80, 80, 80]);
        y += 4;
      }

      if (result?.plagiarismScore !== null && result?.plagiarismScore !== undefined) {
        addText("Plagiarism Analysis", 13, true);
        addText(`Originality Score: ${result.plagiarismScore}%`, 11);
        addText(`Verdict: ${getPlagiarismVerdict(result.plagiarismScore).label}`, 10);
        if (plagiarismDetails?.summary) addText(plagiarismDetails.summary, 9, false, [80, 80, 80]);
        if (plagiarismDetails?.matches?.length) {
          addText("Matched Sources:", 10, true);
          for (const m of plagiarismDetails.matches.slice(0, 5)) {
            addText(`• ${m.similarity}% match — ${m.sourceTitle}: ${m.sourceUrl}`, 8, false, [80, 80, 80]);
          }
        }
        y += 4;
      }

      if (citationDetails?.citations?.length) {
        addText("Citation Validation", 13, true);
        for (const c of citationDetails.citations) {
          addText(`Citation: ${c.original}`, 9, true);
          addText(`Format: ${c.detectedFormat} | Score: ${c.score}% | ${c.isValid ? "Valid" : "Issues found"}`, 9);
          if (c.errors?.length) {
            for (const e of c.errors) {
              addText(`  ⚠ ${e.field}: ${e.message}`, 8, false, [150, 80, 0]);
            }
          }
          if (c.corrected) addText(`Corrected: ${c.corrected}`, 8, false, [0, 100, 0]);
          y += 2;
        }
      }

      doc.save(`scholarscan-report-${scanId}.pdf`);
    } catch (err) {
      console.error(err);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div
        className="fixed inset-0 opacity-[0.02] pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(oklch(0.72 0.18 264) 1px, transparent 1px), linear-gradient(90deg, oklch(0.72 0.18 264) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />

      {/* Nav */}
      <nav className="sticky top-0 z-50 scholar-glass border-b border-border/50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate("/scan")}
              className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              New scan
            </button>
            <div className="w-px h-4 bg-border" />
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-md bg-primary/20 border border-primary/30 flex items-center justify-center">
                <GraduationCap className="w-3.5 h-3.5 text-primary" />
              </div>
              <span className="font-semibold tracking-tight text-sm">ScholarScan</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {result && !isProcessing && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleExportPDF}
                disabled={isExporting}
                className="border-border text-muted-foreground hover:text-foreground"
              >
                {isExporting ? <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> : <Download className="w-3.5 h-3.5 mr-1.5" />}
                Export PDF
              </Button>
            )}
            <Button variant="ghost" size="sm" onClick={() => navigate("/history")} className="text-muted-foreground">
              <History className="w-4 h-4 mr-1.5" />
              History
            </Button>
            <Button variant="ghost" size="sm" onClick={() => signOut.mutate()} className="text-muted-foreground">
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </nav>

      <main className="container py-10 relative z-10">
        <div className="max-w-5xl mx-auto">
          {/* Processing state */}
          {isProcessing && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center py-20"
            >
              <div className="relative inline-flex mb-8">
                <div className="w-20 h-20 rounded-2xl bg-primary/15 border border-primary/30 flex items-center justify-center animate-pulse-glow">
                  <Sparkles className="w-9 h-9 text-primary" />
                </div>
              </div>
              <h2 className="text-2xl font-bold mb-3">Analyzing your text...</h2>
              <p className="text-muted-foreground mb-8 max-w-md mx-auto">
                Running AI detection, plagiarism analysis, and citation validation simultaneously.
                This typically takes 20–40 seconds.
              </p>
              <div className="max-w-xs mx-auto space-y-3">
                {[
                  { icon: Sparkles, label: "AI Content Detection", color: "oklch(0.72 0.18 264)" },
                  { icon: Search, label: "Plagiarism Analysis", color: "oklch(0.72 0.18 145)" },
                  { icon: BookOpen, label: "Citation Validation", color: "oklch(0.72 0.18 55)" },
                ].map((item, i) => (
                  <motion.div
                    key={item.label}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.15 }}
                    className="flex items-center gap-3 scholar-card rounded-lg px-4 py-2.5"
                  >
                    <Loader2 className="w-4 h-4 animate-spin" style={{ color: item.color }} />
                    <span className="text-sm">{item.label}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {/* Failed state */}
          {isFailed && (
            <div className="text-center py-20">
              <XCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
              <h2 className="text-xl font-bold mb-2">Analysis failed</h2>
              <p className="text-muted-foreground mb-6">Something went wrong during analysis.</p>
              <Button onClick={() => navigate("/scan")}>Try again</Button>
            </div>
          )}

          {/* Results */}
          {result && !isProcessing && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
              className="space-y-6"
            >
              {/* Header */}
              <div className="flex items-start justify-between">
                <div>
                  <h1 className="text-2xl font-bold tracking-tight mb-1">Analysis Report</h1>
                  <p className="text-sm text-muted-foreground">
                    {scan?.fileName && <><FileText className="w-3.5 h-3.5 inline mr-1" />{scan.fileName} · </>}
                    {new Date(scan?.createdAt ?? "").toLocaleString()}
                  </p>
                </div>
                <Badge variant="outline" className="border-primary/30 text-primary bg-primary/10">
                  <CheckCircle2 className="w-3 h-3 mr-1" />
                  Complete
                </Badge>
              </div>

              {/* Score dashboard */}
              <div className="scholar-card rounded-2xl p-6">
                <h2 className="font-semibold mb-6 text-sm uppercase tracking-wide text-muted-foreground">
                  Overview
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
                  {result.aiScore !== null && result.aiScore !== undefined && (
                    <div className="flex flex-col items-center">
                      <ScoreGauge
                        score={result.aiScore}
                        color={getAIScoreColor(result.aiScore)}
                        label="AI Detection"
                        sublabel={getAIVerdict(result.aiScore).label}
                      />
                    </div>
                  )}
                  {result.plagiarismScore !== null && result.plagiarismScore !== undefined && (
                    <div className="flex flex-col items-center">
                      <ScoreGauge
                        score={result.plagiarismScore}
                        color={getPlagiarismColor(result.plagiarismScore)}
                        label="Originality"
                        sublabel={getPlagiarismVerdict(result.plagiarismScore).label}
                      />
                    </div>
                  )}
                  {citationDetails?.citations?.length > 0 && (
                    <div className="flex flex-col items-center justify-center">
                      <div className="text-center">
                        <div className="text-4xl font-bold mb-1" style={{ color: "oklch(0.72 0.18 55)" }}>
                          {citationDetails.citations.filter((c: any) => c.isValid).length}
                          <span className="text-2xl text-muted-foreground">/{citationDetails.citations.length}</span>
                        </div>
                        <p className="font-semibold text-sm">Citations Valid</p>
                        <p className="text-xs text-muted-foreground">Format accuracy</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* AI Detection Detail */}
              {aiDetails && (
                <SectionCard
                  id="ai"
                  icon={Sparkles}
                  title="AI Content Detection"
                  iconColor="oklch(0.72 0.18 264)"
                  score={result.aiScore ?? 0}
                  scoreColor={getAIScoreColor(result.aiScore ?? 0)}
                  verdict={getAIVerdict(result.aiScore ?? 0).label}
                  expanded={expandedSections.has("ai")}
                  onToggle={() => toggleSection("ai")}
                >
                  {aiDetails.summary && (
                    <p className="text-sm text-muted-foreground leading-relaxed mb-4">{aiDetails.summary}</p>
                  )}

                  {aiDetails.keyIndicators?.length > 0 && (
                    <div className="mb-4">
                      <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground mb-2">Key Indicators</p>
                      <div className="flex flex-wrap gap-2">
                        {aiDetails.keyIndicators.map((ind: string, i: number) => (
                          <Badge key={i} variant="outline" className="text-xs border-border/60">{ind}</Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {aiDetails.writingPatterns && (
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
                      {Object.entries(aiDetails.writingPatterns).map(([key, val]) => (
                        <div key={key} className="bg-muted/30 rounded-lg p-3 text-center">
                          <p className="text-xs text-muted-foreground capitalize mb-1">{key.replace(/([A-Z])/g, " $1")}</p>
                          <p className={`text-sm font-semibold capitalize ${
                            val === "low" ? "text-green-400" : val === "high" ? "text-red-400" : "text-yellow-400"
                          }`}>{val as string}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  {scan?.inputText && aiDetails.sentences?.length > 0 && (
                    <div>
                      <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground mb-3">
                        Sentence-Level Analysis
                      </p>
                      <div className="bg-muted/20 rounded-lg p-4 border border-border/40">
                        <HighlightedText text={scan.inputText} sentences={aiDetails.sentences} />
                      </div>
                      <div className="flex items-center gap-4 mt-3">
                        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                          <span className="w-3 h-1.5 rounded-full bg-red-500/60 inline-block" /> High AI probability
                        </div>
                        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                          <span className="w-3 h-1.5 rounded-full bg-yellow-500/60 inline-block" /> Medium
                        </div>
                        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                          <span className="w-3 h-1.5 rounded-full bg-green-500/60 inline-block" /> Low
                        </div>
                      </div>
                    </div>
                  )}
                </SectionCard>
              )}

              {/* Plagiarism Detail */}
              {plagiarismDetails && (
                <SectionCard
                  id="plagiarism"
                  icon={Search}
                  title="Plagiarism Analysis"
                  iconColor="oklch(0.72 0.18 145)"
                  score={result.plagiarismScore ?? 100}
                  scoreColor={getPlagiarismColor(result.plagiarismScore ?? 100)}
                  verdict={getPlagiarismVerdict(result.plagiarismScore ?? 100).label}
                  expanded={expandedSections.has("plagiarism")}
                  onToggle={() => toggleSection("plagiarism")}
                >
                  {plagiarismDetails.summary && (
                    <p className="text-sm text-muted-foreground leading-relaxed mb-4">{plagiarismDetails.summary}</p>
                  )}

                  <div className="grid grid-cols-3 gap-3 mb-4">
                    <div className="bg-muted/30 rounded-lg p-3 text-center">
                      <p className="text-xs text-muted-foreground mb-1">Risk Level</p>
                      <p className={`text-sm font-semibold capitalize ${
                        plagiarismDetails.riskLevel === "none" || plagiarismDetails.riskLevel === "low"
                          ? "text-green-400"
                          : plagiarismDetails.riskLevel === "medium"
                          ? "text-yellow-400"
                          : "text-red-400"
                      }`}>{plagiarismDetails.riskLevel}</p>
                    </div>
                    <div className="bg-muted/30 rounded-lg p-3 text-center">
                      <p className="text-xs text-muted-foreground mb-1">Matched Words</p>
                      <p className="text-sm font-semibold">{plagiarismDetails.totalMatchedWords ?? 0}</p>
                    </div>
                    <div className="bg-muted/30 rounded-lg p-3 text-center">
                      <p className="text-xs text-muted-foreground mb-1">Sources Found</p>
                      <p className="text-sm font-semibold">{plagiarismDetails.matches?.length ?? 0}</p>
                    </div>
                  </div>

                  {plagiarismDetails.matches?.length > 0 ? (
                    <div className="space-y-3">
                      <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Matched Sources</p>
                      {plagiarismDetails.matches.map((match: any, i: number) => (
                        <div key={i} className="bg-muted/20 rounded-lg p-4 border border-border/40">
                          <div className="flex items-start justify-between gap-3 mb-2">
                            <div className="flex items-center gap-2 flex-1 min-w-0">
                              <Badge
                                variant="outline"
                                className={`text-xs flex-shrink-0 ${
                                  match.similarity >= 70 ? "border-red-500/40 text-red-400" :
                                  match.similarity >= 40 ? "border-yellow-500/40 text-yellow-400" :
                                  "border-green-500/40 text-green-400"
                                }`}
                              >
                                {match.similarity}% match
                              </Badge>
                              <Badge variant="outline" className="text-xs border-border/40 capitalize">
                                {match.matchType}
                              </Badge>
                              <Badge variant="outline" className="text-xs border-border/40 capitalize">
                                {match.sourceType}
                              </Badge>
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground italic mb-2">"{match.passage}"</p>
                          <div className="flex items-center gap-1.5 text-xs text-primary">
                            <ExternalLink className="w-3 h-3 flex-shrink-0" />
                            <a
                              href={match.sourceUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="hover:underline truncate"
                            >
                              {match.sourceTitle}
                            </a>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex items-center gap-3 bg-green-500/10 border border-green-500/20 rounded-lg p-4">
                      <CheckCircle2 className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <p className="text-sm text-green-400">No significant plagiarism detected.</p>
                    </div>
                  )}
                </SectionCard>
              )}

              {/* Citations Detail */}
              {citationDetails?.citations?.length > 0 && (
                <SectionCard
                  id="citations"
                  icon={BookOpen}
                  title="Citation Validation"
                  iconColor="oklch(0.72 0.18 55)"
                  score={Math.round((citationDetails.citations.filter((c: any) => c.isValid).length / citationDetails.citations.length) * 100)}
                  scoreColor="oklch(0.72 0.18 55)"
                  verdict={`${citationDetails.citations.filter((c: any) => c.isValid).length}/${citationDetails.citations.length} citations valid`}
                  expanded={expandedSections.has("citations")}
                  onToggle={() => toggleSection("citations")}
                >
                  {citationDetails.summary && (
                    <p className="text-sm text-muted-foreground leading-relaxed mb-4">{citationDetails.summary}</p>
                  )}

                  <div className="space-y-4">
                    {citationDetails.citations.map((citation: any, i: number) => (
                      <div key={i} className="bg-muted/20 rounded-lg p-4 border border-border/40">
                        <div className="flex items-start justify-between gap-3 mb-3">
                          <div className="flex items-center gap-2 flex-wrap">
                            {citation.isValid ? (
                              <CheckCircle2 className="w-4 h-4 text-green-400 flex-shrink-0" />
                            ) : (
                              <XCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                            )}
                            <Badge variant="outline" className="text-xs border-border/40">
                              {citation.detectedFormat}
                            </Badge>
                            <Badge
                              variant="outline"
                              className={`text-xs ${
                                citation.score >= 80 ? "border-green-500/40 text-green-400" :
                                citation.score >= 50 ? "border-yellow-500/40 text-yellow-400" :
                                "border-red-500/40 text-red-400"
                              }`}
                            >
                              {citation.score}% correct
                            </Badge>
                          </div>
                        </div>

                        <p className="text-xs text-muted-foreground font-mono bg-muted/30 rounded p-2 mb-3 leading-relaxed">
                          {citation.original}
                        </p>

                        {citation.errors?.length > 0 && (
                          <div className="space-y-2 mb-3">
                            {citation.errors.map((err: any, j: number) => (
                              <div
                                key={j}
                                className={`flex items-start gap-2 text-xs rounded p-2 ${
                                  err.severity === "error"
                                    ? "bg-red-500/10 border border-red-500/20"
                                    : err.severity === "warning"
                                    ? "bg-yellow-500/10 border border-yellow-500/20"
                                    : "bg-blue-500/10 border border-blue-500/20"
                                }`}
                              >
                                {err.severity === "error" ? (
                                  <XCircle className="w-3.5 h-3.5 text-red-400 flex-shrink-0 mt-0.5" />
                                ) : err.severity === "warning" ? (
                                  <AlertTriangle className="w-3.5 h-3.5 text-yellow-400 flex-shrink-0 mt-0.5" />
                                ) : (
                                  <Info className="w-3.5 h-3.5 text-blue-400 flex-shrink-0 mt-0.5" />
                                )}
                                <div>
                                  <span className="font-medium capitalize">{err.field}: </span>
                                  <span className="text-muted-foreground">{err.message}</span>
                                  {err.suggestion && (
                                    <p className="text-primary mt-0.5">→ {err.suggestion}</p>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}

                        {citation.corrected && citation.corrected !== citation.original && (
                          <div className="bg-green-500/10 border border-green-500/20 rounded p-2">
                            <p className="text-xs text-green-400 font-medium mb-1">Corrected citation:</p>
                            <p className="text-xs font-mono text-foreground/80 leading-relaxed">{citation.corrected}</p>
                          </div>
                        )}

                        {citation.explanation && (
                          <p className="text-xs text-muted-foreground mt-2 leading-relaxed">{citation.explanation}</p>
                        )}
                      </div>
                    ))}
                  </div>
                </SectionCard>
              )}
            </motion.div>
          )}
        </div>
      </main>
    </div>
  );
}

// ─── Section card component ───────────────────────────────────────────────────

function SectionCard({
  id,
  icon: Icon,
  title,
  iconColor,
  score,
  scoreColor,
  verdict,
  expanded,
  onToggle,
  children,
}: {
  id: string;
  icon: any;
  title: string;
  iconColor: string;
  score: number;
  scoreColor: string;
  verdict: string;
  expanded: boolean;
  onToggle: () => void;
  children: React.ReactNode;
}) {
  return (
    <div className="scholar-card rounded-2xl overflow-hidden">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between p-5 hover:bg-white/[0.02] transition-colors"
      >
        <div className="flex items-center gap-3">
          <div
            className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
            style={{ background: `${iconColor}18`, border: `1px solid ${iconColor}28` }}
          >
            <Icon className="w-4.5 h-4.5" style={{ color: iconColor }} />
          </div>
          <div className="text-left">
            <p className="font-semibold text-sm">{title}</p>
            <p className="text-xs text-muted-foreground">{verdict}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <span className="text-lg font-bold" style={{ color: scoreColor }}>{score}%</span>
          </div>
          {expanded ? (
            <ChevronUp className="w-4 h-4 text-muted-foreground" />
          ) : (
            <ChevronDown className="w-4 h-4 text-muted-foreground" />
          )}
        </div>
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: [0.23, 1, 0.32, 1] }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5 border-t border-border/40 pt-4">{children}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
