// Redirect to Landing
export { default } from "./Landing";
