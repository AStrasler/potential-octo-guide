import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { useScholarAuth } from "@/hooks/useScholarAuth";
import {
  GraduationCap,
  ArrowLeft,
  Mail,
  KeyRound,
  Loader2,
  CheckCircle2,
  RefreshCw,
} from "lucide-react";

type Step = "email" | "otp" | "success";

export default function Verify() {
  const [, navigate] = useLocation();
  const { authenticated, loading } = useScholarAuth();
  const [step, setStep] = useState<Step>("email");
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [countdown, setCountdown] = useState(0);
  const otpRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    if (!loading && authenticated) navigate("/scan");
  }, [authenticated, loading, navigate]);

  useEffect(() => {
    if (countdown > 0) {
      const t = setTimeout(() => setCountdown((c) => c - 1), 1000);
      return () => clearTimeout(t);
    }
  }, [countdown]);

  const sendCode = trpc.emailAuth.sendCode.useMutation({
    onSuccess: () => {
      setStep("otp");
      setCountdown(60);
      toast.success("Verification code sent!", {
        description: "Check your email inbox.",
      });
      setTimeout(() => otpRefs.current[0]?.focus(), 300);
    },
    onError: (err) => {
      toast.error(err.message);
    },
  });

  const verifyCode = trpc.emailAuth.verifyCode.useMutation({
    onSuccess: () => {
      setStep("success");
      setTimeout(() => navigate("/scan"), 1500);
    },
    onError: (err) => {
      toast.error(err.message);
      setOtp(["", "", "", "", "", ""]);
      otpRefs.current[0]?.focus();
    },
  });

  const handleOtpChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    const newOtp = [...otp];
    newOtp[index] = value.slice(-1);
    setOtp(newOtp);
    if (value && index < 5) {
      otpRefs.current[index + 1]?.focus();
    }
    // Auto-submit when all filled
    if (newOtp.every((d) => d !== "") && newOtp.join("").length === 6) {
      verifyCode.mutate({ email, code: newOtp.join("") });
    }
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      otpRefs.current[index - 1]?.focus();
    }
  };

  const handleOtpPaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6);
    if (pasted.length === 6) {
      const newOtp = pasted.split("");
      setOtp(newOtp);
      verifyCode.mutate({ email, code: pasted });
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Background */}
      <div
        className="fixed inset-0 opacity-[0.025] pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(oklch(0.72 0.18 264) 1px, transparent 1px), linear-gradient(90deg, oklch(0.72 0.18 264) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />
      <div
        className="fixed top-0 left-1/2 -translate-x-1/2 w-[500px] h-[300px] rounded-full opacity-8 blur-3xl pointer-events-none"
        style={{ background: "radial-gradient(circle, oklch(0.72 0.18 264), transparent 70%)" }}
      />

      {/* Header */}
      <div className="relative z-10 p-6">
        <button
          onClick={() => (step === "otp" ? setStep("email") : navigate("/"))}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          {step === "otp" ? "Change email" : "Back to home"}
        </button>
      </div>

      {/* Main */}
      <div className="flex-1 flex items-center justify-center p-6 relative z-10">
        <div className="w-full max-w-md">
          {/* Logo */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
            className="flex items-center justify-center gap-2 mb-10"
          >
            <div className="w-10 h-10 rounded-xl bg-primary/20 border border-primary/30 flex items-center justify-center scholar-glow">
              <GraduationCap className="w-5 h-5 text-primary" />
            </div>
            <span className="text-xl font-semibold tracking-tight">ScholarScan</span>
          </motion.div>

          <AnimatePresence mode="wait">
            {step === "email" && (
              <motion.div
                key="email"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.35, ease: [0.23, 1, 0.32, 1] }}
              >
                <div className="scholar-card rounded-2xl p-8">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 rounded-lg bg-primary/15 border border-primary/25 flex items-center justify-center">
                      <Mail className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h1 className="text-xl font-semibold">Verify your email</h1>
                      <p className="text-sm text-muted-foreground">
                        .edu addresses only
                      </p>
                    </div>
                  </div>

                  <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
                    ScholarScan is exclusively available to verified university students. Enter your
                    .edu email address to receive a one-time access code.
                  </p>

                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      sendCode.mutate({ email });
                    }}
                    className="space-y-4"
                  >
                    <div>
                      <Input
                        type="email"
                        placeholder="you@university.edu"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="bg-muted/50 border-border h-11 text-base"
                        autoFocus
                        required
                      />
                    </div>
                    <Button
                      type="submit"
                      className="w-full h-11 bg-primary text-primary-foreground hover:bg-primary/90 font-medium transition-all duration-150 active:scale-[0.98]"
                      disabled={sendCode.isPending || !email}
                    >
                      {sendCode.isPending ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Sending code...
                        </>
                      ) : (
                        "Send verification code"
                      )}
                    </Button>
                  </form>

                  <p className="text-xs text-muted-foreground text-center mt-4">
                    Access is restricted to .edu email addresses and approved users.
                  </p>
                </div>
              </motion.div>
            )}

            {step === "otp" && (
              <motion.div
                key="otp"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.35, ease: [0.23, 1, 0.32, 1] }}
              >
                <div className="scholar-card rounded-2xl p-8">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 rounded-lg bg-primary/15 border border-primary/25 flex items-center justify-center">
                      <KeyRound className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h1 className="text-xl font-semibold">Enter your code</h1>
                      <p className="text-sm text-muted-foreground truncate max-w-[220px]">
                        Sent to {email}
                      </p>
                    </div>
                  </div>

                  <p className="text-sm text-muted-foreground mb-6">
                    We sent a 6-digit code to your email. It expires in 15 minutes.
                  </p>

                  {/* OTP inputs */}
                  <div className="flex gap-2 justify-center mb-6" onPaste={handleOtpPaste}>
                    {otp.map((digit, i) => (
                      <input
                        key={i}
                        ref={(el) => { otpRefs.current[i] = el; }}
                        type="text"
                        inputMode="numeric"
                        maxLength={1}
                        value={digit}
                        onChange={(e) => handleOtpChange(i, e.target.value)}
                        onKeyDown={(e) => handleOtpKeyDown(i, e)}
                        className="w-12 h-14 text-center text-xl font-semibold rounded-lg border border-border bg-muted/50 text-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors"
                      />
                    ))}
                  </div>

                  <Button
                    className="w-full h-11 bg-primary text-primary-foreground hover:bg-primary/90 font-medium transition-all duration-150 active:scale-[0.98]"
                    disabled={verifyCode.isPending || otp.some((d) => !d)}
                    onClick={() => verifyCode.mutate({ email, code: otp.join("") })}
                  >
                    {verifyCode.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Verifying...
                      </>
                    ) : (
                      "Verify & access ScholarScan"
                    )}
                  </Button>

                  <div className="flex items-center justify-center mt-4">
                    {countdown > 0 ? (
                      <span className="text-xs text-muted-foreground">
                        Resend in {countdown}s
                      </span>
                    ) : (
                      <button
                        onClick={() => {
                          sendCode.mutate({ email });
                          setCountdown(60);
                        }}
                        className="flex items-center gap-1.5 text-xs text-primary hover:text-primary/80 transition-colors"
                      >
                        <RefreshCw className="w-3 h-3" />
                        Resend code
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            )}

            {step === "success" && (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.35, ease: [0.23, 1, 0.32, 1] }}
                className="text-center"
              >
                <div className="scholar-card rounded-2xl p-10">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.1, type: "spring", stiffness: 200, damping: 15 }}
                    className="flex justify-center mb-4"
                  >
                    <div className="w-16 h-16 rounded-full bg-primary/15 border border-primary/30 flex items-center justify-center scholar-glow">
                      <CheckCircle2 className="w-8 h-8 text-primary" />
                    </div>
                  </motion.div>
                  <h2 className="text-xl font-semibold mb-2">Access granted</h2>
                  <p className="text-sm text-muted-foreground">
                    Redirecting you to ScholarScan...
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
