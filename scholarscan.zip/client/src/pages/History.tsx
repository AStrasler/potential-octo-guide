import { useState } from "react";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useRequireAuth } from "@/hooks/useScholarAuth";
import {
  GraduationCap,
  ArrowLeft,
  Search,
  Sparkles,
  BookOpen,
  FileText,
  LogOut,
  Loader2,
  ChevronRight,
  Clock,
  Inbox,
} from "lucide-react";

function ScorePill({ score, type }: { score: number; type: "ai" | "originality" }) {
  const color =
    type === "ai"
      ? score >= 70 ? "border-red-500/40 text-red-400" : score >= 40 ? "border-yellow-500/40 text-yellow-400" : "border-green-500/40 text-green-400"
      : score >= 80 ? "border-green-500/40 text-green-400" : score >= 50 ? "border-yellow-500/40 text-yellow-400" : "border-red-500/40 text-red-400";

  return (
    <Badge variant="outline" className={`text-xs ${color}`}>
      {score}%
    </Badge>
  );
}

export default function History() {
  const [, navigate] = useLocation();
  const { email } = useRequireAuth();
  const [search, setSearch] = useState("");

  const signOut = trpc.emailAuth.signOut.useMutation({ onSuccess: () => navigate("/") });

  const { data, isLoading } = trpc.scan.history.useQuery({ limit: 50, offset: 0 });

  const filtered = (data ?? []).filter(({ scan }) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      scan.inputText.toLowerCase().includes(q) ||
      (scan.fileName ?? "").toLowerCase().includes(q)
    );
  });

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div
        className="fixed inset-0 opacity-[0.02] pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(oklch(0.72 0.18 264) 1px, transparent 1px), linear-gradient(90deg, oklch(0.72 0.18 264) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />

      {/* Nav */}
      <nav className="sticky top-0 z-50 scholar-glass border-b border-border/50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate("/scan")}
              className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              New scan
            </button>
            <div className="w-px h-4 bg-border" />
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-md bg-primary/20 border border-primary/30 flex items-center justify-center">
                <GraduationCap className="w-3.5 h-3.5 text-primary" />
              </div>
              <span className="font-semibold tracking-tight text-sm">ScholarScan</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="hidden sm:block text-xs text-muted-foreground">{email}</span>
            <Button variant="ghost" size="sm" onClick={() => signOut.mutate()} className="text-muted-foreground">
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </nav>

      <main className="container py-10 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: [0.23, 1, 0.32, 1] }}
          className="max-w-4xl mx-auto"
        >
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-2xl font-bold tracking-tight mb-1">Scan History</h1>
              <p className="text-sm text-muted-foreground">
                {filtered.length} scan{filtered.length !== 1 ? "s" : ""} found
              </p>
            </div>
            <Button
              onClick={() => navigate("/scan")}
              className="bg-primary text-primary-foreground hover:bg-primary/90 transition-all duration-150 active:scale-[0.97]"
            >
              New Scan
            </Button>
          </div>

          {/* Search */}
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search scans..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 bg-muted/50 border-border h-10"
            />
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="w-6 h-6 text-primary animate-spin" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-20">
              <div className="w-14 h-14 rounded-2xl bg-muted/50 border border-border flex items-center justify-center mx-auto mb-4">
                <Inbox className="w-7 h-7 text-muted-foreground" />
              </div>
              <h3 className="font-semibold mb-2">No scans yet</h3>
              <p className="text-sm text-muted-foreground mb-6">
                Your completed scans will appear here.
              </p>
              <Button onClick={() => navigate("/scan")}>Run your first scan</Button>
            </div>
          ) : (
            <div className="space-y-3">
              {filtered.map(({ scan, result }, i) => {
                const preview = scan.inputText.slice(0, 120).trim();
                const aiDetails = result?.aiDetailsJson as any;
                const plagDetails = result?.plagiarismDetailsJson as any;
                const citDetails = result?.citationsJson as any;

                return (
                  <motion.button
                    key={scan.id}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: i * 0.04, ease: [0.23, 1, 0.32, 1] }}
                    onClick={() => navigate(`/results/${scan.id}`)}
                    className="w-full text-left scholar-card rounded-xl p-4 hover:border-border/80 transition-all duration-150 active:scale-[0.99] group"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1.5">
                          {scan.fileName ? (
                            <FileText className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                          ) : (
                            <FileText className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                          )}
                          <span className="text-xs text-muted-foreground font-medium truncate">
                            {scan.fileName ?? "Pasted text"}
                          </span>
                          <span className="text-xs text-muted-foreground/50">·</span>
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {new Date(scan.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}
                          </span>
                        </div>
                        <p className="text-sm text-foreground/80 leading-relaxed line-clamp-2">
                          {preview}{preview.length < scan.inputText.length ? "..." : ""}
                        </p>

                        {result && (
                          <div className="flex items-center gap-2 mt-2.5 flex-wrap">
                            {result.aiScore !== null && result.aiScore !== undefined && (
                              <div className="flex items-center gap-1.5">
                                <Sparkles className="w-3 h-3 text-muted-foreground" />
                                <span className="text-xs text-muted-foreground">AI:</span>
                                <ScorePill score={result.aiScore} type="ai" />
                              </div>
                            )}
                            {result.plagiarismScore !== null && result.plagiarismScore !== undefined && (
                              <div className="flex items-center gap-1.5">
                                <Search className="w-3 h-3 text-muted-foreground" />
                                <span className="text-xs text-muted-foreground">Original:</span>
                                <ScorePill score={result.plagiarismScore} type="originality" />
                              </div>
                            )}
                            {citDetails?.citations?.length > 0 && (
                              <div className="flex items-center gap-1.5">
                                <BookOpen className="w-3 h-3 text-muted-foreground" />
                                <span className="text-xs text-muted-foreground">
                                  {citDetails.citations.filter((c: any) => c.isValid).length}/{citDetails.citations.length} citations valid
                                </span>
                              </div>
                            )}
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-2 flex-shrink-0">
                        <Badge
                          variant="outline"
                          className={`text-xs ${
                            scan.status === "completed" ? "border-green-500/30 text-green-400" :
                            scan.status === "processing" ? "border-primary/30 text-primary" :
                            "border-red-500/30 text-red-400"
                          }`}
                        >
                          {scan.status}
                        </Badge>
                        <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors" />
                      </div>
                    </div>
                  </motion.button>
                );
              })}
            </div>
          )}
        </motion.div>
      </main>
    </div>
  );
}
