import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useScholarAuth } from "@/hooks/useScholarAuth";
import { useEffect } from "react";
import {
  ShieldCheck,
  Sparkles,
  Search,
  BookOpen,
  ArrowRight,
  CheckCircle2,
  Zap,
  Lock,
  GraduationCap,
} from "lucide-react";

const features = [
  {
    icon: Sparkles,
    title: "AI Content Detection",
    description:
      "Sentence-level analysis with confidence scoring. Identifies AI-generated patterns with professional-grade accuracy.",
    color: "oklch(0.72 0.18 264)",
  },
  {
    icon: Search,
    title: "Plagiarism Checker",
    description:
      "Deep semantic comparison against academic papers, websites, and publications. Returns matched sources with similarity percentages.",
    color: "oklch(0.72 0.18 145)",
  },
  {
    icon: BookOpen,
    title: "Citation Validator",
    description:
      "Field-by-field validation for APA, MLA, Chicago, and Harvard formats with precise error highlighting and corrections.",
    color: "oklch(0.72 0.18 55)",
  },
];

const stats = [
  { value: "99.2%", label: "Detection Accuracy" },
  { value: "4", label: "Citation Formats" },
  { value: "<30s", label: "Analysis Time" },
  { value: "Free", label: "For Students" },
];

export default function Landing() {
  const [, navigate] = useLocation();
  const { authenticated, loading } = useScholarAuth();

  useEffect(() => {
    if (!loading && authenticated) {
      navigate("/scan");
    }
  }, [authenticated, loading, navigate]);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 scholar-glass border-b border-border/50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/20 border border-primary/30 flex items-center justify-center">
              <GraduationCap className="w-4 h-4 text-primary" />
            </div>
            <span className="font-semibold text-foreground tracking-tight">ScholarScan</span>
          </div>
          <Button
            onClick={() => navigate("/verify")}
            size="sm"
            className="bg-primary text-primary-foreground hover:bg-primary/90 transition-all duration-150 active:scale-[0.97]"
          >
            Get Access
            <ArrowRight className="w-3.5 h-3.5 ml-1.5" />
          </Button>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative pt-32 pb-24 overflow-hidden">
        {/* Background grid */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage:
              "linear-gradient(oklch(0.72 0.18 264) 1px, transparent 1px), linear-gradient(90deg, oklch(0.72 0.18 264) 1px, transparent 1px)",
            backgroundSize: "60px 60px",
          }}
        />
        {/* Glow orbs */}
        <div
          className="absolute top-20 left-1/2 -translate-x-1/2 w-[600px] h-[400px] rounded-full opacity-10 blur-3xl pointer-events-none"
          style={{ background: "radial-gradient(circle, oklch(0.72 0.18 264), transparent 70%)" }}
        />

        <div className="container relative text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
          >
            <Badge
              variant="outline"
              className="mb-6 border-primary/30 text-primary bg-primary/10 px-4 py-1.5 text-xs font-medium tracking-wide uppercase"
            >
              <Lock className="w-3 h-3 mr-1.5" />
              Exclusive to .edu Students
            </Badge>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.05, ease: [0.23, 1, 0.32, 1] }}
            className="text-5xl sm:text-6xl lg:text-7xl font-bold tracking-tight leading-[1.08] mb-6"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Academic Integrity,{" "}
            <span className="text-gradient">Perfected.</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.12, ease: [0.23, 1, 0.32, 1] }}
            className="text-lg text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed"
          >
            Professional-grade AI detection, plagiarism analysis, and citation validation — all in
            one elegant tool. Built exclusively for students, completely free.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.18, ease: [0.23, 1, 0.32, 1] }}
            className="flex flex-col sm:flex-row gap-3 justify-center"
          >
            <Button
              size="lg"
              onClick={() => navigate("/verify")}
              className="bg-primary text-primary-foreground hover:bg-primary/90 px-8 h-12 text-base font-medium shadow-lg shadow-primary/20 transition-all duration-150 active:scale-[0.97]"
            >
              Start Scanning Free
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.28, ease: [0.23, 1, 0.32, 1] }}
            className="grid grid-cols-2 sm:grid-cols-4 gap-6 mt-20 max-w-2xl mx-auto"
          >
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-3xl font-bold text-gradient mb-1">{stat.value}</div>
                <div className="text-xs text-muted-foreground uppercase tracking-wide">
                  {stat.label}
                </div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="py-24 relative">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
              Three tools. One unified platform.
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Every check runs simultaneously and results are displayed in a single, comprehensive
              report — no switching between tools.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6">
            {features.map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.08, ease: [0.23, 1, 0.32, 1] }}
                className="scholar-card p-6 rounded-xl group hover:border-border/80 transition-colors duration-200"
              >
                <div
                  className="w-11 h-11 rounded-lg flex items-center justify-center mb-4"
                  style={{ background: `${feature.color}20`, border: `1px solid ${feature.color}30` }}
                >
                  <feature.icon className="w-5 h-5" style={{ color: feature.color }} />
                </div>
                <h3 className="font-semibold text-foreground mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-24 border-t border-border/50">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
              Ready in under a minute
            </h2>
          </motion.div>

          <div className="grid sm:grid-cols-3 gap-8 max-w-3xl mx-auto">
            {[
              {
                step: "01",
                title: "Verify your .edu email",
                desc: "Enter your university email and confirm with a one-time code.",
              },
              {
                step: "02",
                title: "Paste or upload your text",
                desc: "Submit plain text or upload a .txt / .docx file for analysis.",
              },
              {
                step: "03",
                title: "Get your full report",
                desc: "Receive AI scores, plagiarism matches, and citation corrections instantly.",
              },
            ].map((item, i) => (
              <motion.div
                key={item.step}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.08, ease: [0.23, 1, 0.32, 1] }}
                className="text-center"
              >
                <div className="text-5xl font-bold text-gradient opacity-30 mb-3">{item.step}</div>
                <h3 className="font-semibold mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 border-t border-border/50">
        <div className="container text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
          >
            <div className="inline-flex items-center gap-2 mb-6">
              <ShieldCheck className="w-5 h-5 text-primary" />
              <span className="text-sm text-muted-foreground">
                Restricted to verified .edu addresses
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
              Ready to scan your work?
            </h2>
            <p className="text-muted-foreground mb-8 max-w-md mx-auto">
              Free for all verified students. No subscription, no limits on scans.
            </p>
            <Button
              size="lg"
              onClick={() => navigate("/verify")}
              className="bg-primary text-primary-foreground hover:bg-primary/90 px-10 h-12 text-base font-medium shadow-lg shadow-primary/20 transition-all duration-150 active:scale-[0.97]"
            >
              <Zap className="w-4 h-4 mr-2" />
              Get Started Free
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 py-8">
        <div className="container flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <GraduationCap className="w-4 h-4" />
            <span>ScholarScan — Academic Integrity Suite</span>
          </div>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <CheckCircle2 className="w-3.5 h-3.5 text-primary/60" />
            <span>Access restricted to verified .edu emails</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
